public class MiscStringOperationsDriver
{
        public static void main(String[] args)
        {
                // Test the wordCount method
                int numWords = MiscStringOperations.wordCount("There are five words here.");
                System.out.printf("Number of words: %d\n\n", numWords);

                // Test the arrayToString method
                char[] letters = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
                String lettersToString = MiscStringOperations.arrayToString(letters);
                System.out.printf("The string is: %s\n\n", lettersToString);

                // Test the mostFrequent method
                char mostFrequentChar = MiscStringOperations.mostFrequent("aababbcddaa");
                System.out.printf("The most-frequent character is: %c\n\n", mostFrequentChar);

                // Test the replaceSubstring method
                String stringWithReplacements = MiscStringOperations.replaceSubstring(
                                "the dog jumped over the fence", "the", "that");
                System.out.printf("The string is: %s\n\n", stringWithReplacements);
        }
}