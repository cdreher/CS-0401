public class SavingsAccount extends BankAccount
{
	private boolean status;
	
	public SavingsAccount(double balance, double interestRate)
	{
		super(balance, interestRate);
		
		if(balance <= 25.0)
			status = false;
	}
	
	public void withdraw(double amount)
	{
		if(status)
			super.withdraw(amount);
		else
			System.out.println("Account is inactive.");
	}
	
	public void deposit(double amount)
	{
		if(status == false)
		{
			if(balance + amount >= 25.0)
				status = true;
		}
		
		super.deposit(amount);
	}
	
	public void monthlyProcess()
	{
		if(numWithdrawals > 4)
			monthlyServiceCharge = (numWithdrawals - 4);
		super.monthlyProcess();
		if(balance < 25)
			status = false;
	}
}