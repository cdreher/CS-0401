import java.util.Scanner;
import java.util.Random;

public class Lab6
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		int guess, number, difficulty, tries;
		boolean playerWon = false;
		
		System.out.print("Please enter a difficulty level (1-3):");
		difficulty = keyboard.nextInt();
		number = r.nextInt(10);
		
		if(difficulty == 1)
		{
			tries = 8;
			System.out.println("You have selected the easy difficulty.\n");
		}
		
		else if(difficulty == 2)
		{
			tries = 5;
			System.out.println("You have selected the moderate difficulty.\n");
		}
		
		else
		{
			tries = 3;
			System.out.println("You have selected the hard difficulty.\n");
		}
		
		for(int i = tries; i > 0; i--)
		{
			System.out.println("Guesses Remaining: " + i);
			System.out.print("Please enter a guess:");
			guess = keyboard.nextInt();
			
			if(guess > number)
				System.out.println("Your guess is too high.\n");
			
			else if(guess < number)
				System.out.println("Your guess is too low.\n");
			
			else
			{
				playerWon = true;
				break;
			}
		}
		
		if(playerWon)
		{
			System.out.println("You win! Please play again soon!");
			System.exit(0);
		}
		
		else
		{
			System.out.println("Sorry, you did not guess the correct answer without the allotted number of guesses. The correct answer is: " + number);
			System.out.println("Thanks for playing! Please play again soon!");
		}
		
	}
}