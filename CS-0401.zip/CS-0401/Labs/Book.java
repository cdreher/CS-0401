public class Book
{
	private String title, author, isbn, subject;
	private boolean fiction;
	private int editionNumber;
	
	public Book(String title, String author, String isbn, String subject, boolean fiction, int editionNumber)
	{
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.subject = subject;
		this.fiction = fiction;
		this.editionNumber = editionNumber;
	}
	
	public Book(String isbn)
	{
		this.title = null;
		this.author = null;
		this.isbn = isbn;
		this.subject = null;
		this.fiction = false;
		this.editionNumber = 0;
	}
	
	public Book(Book b)
	{
		title = b.getTitle();
		author = b.getAuthor();
		isbn = b.getIsbn();
		subject = b.getSubject();
		fiction = b.getFiction();
		editionNumber = b.getEditionNumber();
		
	}
	
	public String getTitle()
	{
		return title;
	}
	
	public void setTitle(String title)
	{
		this.title = title;
	}
	
	public String getAuthor()
	{
		return author;
	}
	
	public void setAuthor(String author)
	{
		this.author = author;
	}
	
	public String getIsbn()
	{
		return isbn;
	}
	
	public void setIsbn(String isbn)
	{
		this.isbn = isbn;
	}
	
	public String getSubject()
	{
		return subject;
	}
	
	public void setSubject(String subject)
	{
		this.subject = subject;
	}
	
	public boolean getFiction()
	{
		return fiction;
	}
	
	public void setFiction(boolean fiction)
	{
		this.fiction = fiction;
	}
	
	public int getEditionNumber()
	{
		return editionNumber;
	}
	
	public void setEditionNumber(int editionNumber)
	{
		this.editionNumber = editionNumber;
	}
	
	public String toString()
	{
		if(fiction == false)
			return "Title: " + title + "\nAuthor: " + author + "\nISBN: " + isbn + "\nSubject: " + subject + "\nFiction?: No\nEdition: " + editionNumber;
		return "Title: " + title + "\nAuthor: " + author + "\nISBN: " + isbn + "\nSubject: " + subject + "\nFiction?: Yes\nEdition: " + editionNumber;
	}
	
	public Book copy(Book b)
	{
		return new Book(b.getTitle(), b.getAuthor(), b.getIsbn(), b.getSubject(), b.getFiction(), b.getEditionNumber());
	}
	
	public boolean equals(Book b)
	{
		if(title == b.getTitle() && author == b.getAuthor() && isbn == b.getIsbn() && subject == b.getSubject() && fiction == b.getFiction() && editionNumber == b.getEditionNumber())
			return true;
		return false;
	}
	
	public boolean equals(String isbn)
	{
		if(isbn == this.isbn)
			return true;
		return false;
	}
}