public class Lab7
{
	public static void main(String[] args)
	{
		//create arrays
		int[] array1 = { 4, 5, 6, 2, 3, 8 };
		int[] array2 = { -2, 19, 0, -6, 5, -11, 3 };

		//Array #1
		System.out.print("Array #1: [ ");
		printArrayElements(array1);
		System.out.println("All elements that are greater than 5 are: ");
		larger_than_n(array1, 5);

		System.out.println("\n-----------------------------\n");

		//Array #2
		System.out.print("Array #2: [ ");
		printArrayElements(array2);
		System.out.println("All elements that are greater than -3 are: ");
		larger_than_n(array2, -3);
	}

	public static void printArrayElements(int[] array)
	{
		for (int i = 0; i < array.length; i++)
		{
			if (i == array.length - 1)
				System.out.println(array[i] + " ]");
			else
				System.out.print(array[i] + ", ");
		}
	}

	//TODO: Define the method larger_than_n()
	public static void larger_than_n(int[] a, int n)
	{
		for(int i = 0; i < a.length; i++)
			if(a[i] > n)
				System.out.println(a[i]);
			
	}

}