public class MiscStringOperations
{
	public static int wordCount(String s)
	{
		int words = 1;
		
		for(int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i) == ' ')
				words++;
		}
		
		return words;
	}
	
	public static String arrayToString(char[] charArray)
	{
		StringBuilder sb = new StringBuilder("");
		String s;
		
		for(int i = 0; i < charArray.length; i++)
		{
			sb.append(charArray[i]);
		}
		
		s = sb.toString();
		
		return s;
	}
	
	public static char mostFrequent(String s)
	{
		int occurence = 0, maxOccurence = 0, i = 0, j = 0;
		char c = s.charAt(0);
		
		while(i < s.length())
		{
			while(j < s.length())
			{
				if(s.charAt(i) == s.charAt(j))
				{
					occurence++;
				}
				j++;
			}
			
			if(occurence > maxOccurence)
			{
				maxOccurence = occurence;
				c = s.charAt(i);
			}
			i++;
			j = 0;
			occurence = 0;
		}
		
		return c;
	}
	
	public static String replaceSubstring(String s1, String s2, String s3)
	{
		return s1.replaceAll(s2, s3);
	}
}