import java.util.Scanner;
import java.text.DecimalFormat;

public class Lab3
{
	public static void main (String[] args)
	{
		DecimalFormat df = new DecimalFormat("#.##");
		Scanner keyboard = new Scanner(System.in);
		int calculation;
		double radius;
		double height;
		double temp;
		double result;
		
		System.out.println("Welcome to the Calculation Program!\n\n1. Area of a Circle\n2. Volume of a sphere\n3. Volume of a cylindrical solid\n4. Fahrenheit to Celcius Conversion");
		
		System.out.println("\nPlease select a calculation:");
		calculation = keyboard.nextInt();
		
		if(calculation == 1)
		{
			System.out.println("Enter radius:");
			radius = keyboard.nextDouble();
			result = Math.PI * Math.pow(radius,2);
			System.out.println("The area of the circle with radius " + radius + " is " + df.format(result) + " units^2");
		}
		
		else if(calculation == 2)
		{
			System.out.println("Enter radius:");
			radius = keyboard.nextDouble();
			result = (4/3.0) * Math.PI * Math.pow(radius,3);
			System.out.println("The volume of the sphere with radius " + radius + " is " + df.format(result) + " units^3");
		}
		
		else if(calculation == 3)
		{
			System.out.println("Enter radius:");
			radius = keyboard.nextDouble();
			System.out.println("Enter height:");
			height = keyboard.nextDouble();
			result = height * Math.PI * Math.pow(radius,2);
			System.out.println("The volume of the cylindrical solid with radius " + radius + " and height " + height + " is " + df.format(result) + " units^3");
		}
		
		else
		{
			System.out.println("Enter the Fahrenheit temp:");
			temp = keyboard.nextDouble();
			result = (5/9.0) * (temp - 32.0);
			System.out.println(temp + " degrees Fahrenheit is equal to " + df.format(result) + " degrees Celcius");
		}
	}
}