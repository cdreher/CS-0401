import java.util.Scanner;

public class Lab4
{
	public static void main (String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Please enter the vehicle's speed in MPH:");
		int speed = keyboard.nextInt();
		System.out.print("Please enter the number of hours traveled:");
		int hours = keyboard.nextInt();
		
		System.out.println("Hours\t\tDistance Traveled");
		System.out.println("--------------------------");
		for(int i = 1; i <= hours; i++)
		{
			System.out.println(i + "\t\t" + (i*speed));
		}
	}
}