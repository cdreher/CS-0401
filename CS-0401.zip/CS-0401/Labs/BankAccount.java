public abstract class BankAccount
{
	public double balance, interestRate, monthlyServiceCharge;
	public int numWithdrawals, numDeposits;
	
	public BankAccount(double balance, double interestRate)
	{
		this.balance = balance;
		this.interestRate = interestRate;
		numDeposits = 0;
		numWithdrawals = 0;
		monthlyServiceCharge = 0.0;
	}
	
	public void deposit(double amount)
	{
		balance += amount;
		numDeposits++;
	}
	
	public void withdraw(double amount)
	{
		balance -= amount;
		numWithdrawals++;
	}
	
	public void calcInterest(double balance, double interestRate)
	{
		double monthlyInterestRate = interestRate / 12.0;
		double monthlyInterest = balance * monthlyInterestRate;
		balance += monthlyInterest;
	}
	
	public void monthlyProcess(double monthlyServiceCharge, double balance, double interestRate, int numWithdrawals, int numDeposits)
	{
		balance -= monthlyServiceCharge;
		calcInterest(balance, interestRate);
		numDeposits = 0;
		numWithdrawals = 0;
		monthlyServiceCharge = 0.0;
	}
	
}