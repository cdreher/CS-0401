public class TaxCalculatorDriver
{
	public static void main(String[] args)
	{
		TaxCalculator x = new TaxCalculator();
	}
}