import javax.swing.JOptionPane;

public class Flutter
{
	public static void main(String[] args)
	{
		String flap;
		
		//Collects info via Input DialogBox
		flap = JOptionPane.showInputDialog(null,"Enter your flap:", "Flutter", JOptionPane.QUESTION_MESSAGE);
		
		//Displays DialogBox
		JOptionPane.showMessageDialog(null, flap, "Flutter", JOptionPane.QUESTION_MESSAGE);
		
		//Ends program
		System.exit(0);
	}
}