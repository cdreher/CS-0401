import java.util.Scanner; // Needed for the Scanner class
import java.io.*;         // Needed for the File class

/**
   This program reads data from a file.
*/

public class Lab8
{
    public static void main(String[] args) throws IOException
    {
        // Use String variables to store the data
        String id; String name= ""; String location = ""; String day = ""; String time = ""; String course = "";
		Scanner keyboard = new Scanner(System.in);
		
		//Prompt user to enter ID number.
		System.out.print("Please enter your student ID number: ");
		id = keyboard.next();

        // Open StudentInfo.txt and set the comma as the token delimiter
        File file = new File("StudentInfo.txt");
        Scanner studentInputFile = new Scanner(file);
		PrintWriter scheduleWriter = new PrintWriter("Schedule.txt");

        // Read lines from the file until no more are left.
        while (studentInputFile.hasNext())
        {
            // Read the next row from StudentInfo.txt
            String studentRow = studentInputFile.nextLine();

			// Use split() to parse the row into id, name, and course
            String[] studentInfo = studentRow.split(",");
			
			if(id.equals(studentInfo[0]))
			{
				name = studentInfo[1];
				course = studentInfo[2];
				break;
			}
			
			else
			{
				System.out.println("No record could be found");
				System.exit(0);
			}
            
        }

        // Close the connection to StudentInfo.txt
        studentInputFile.close();
		
		//Open CourseInfo.txt and set the comma as the token delimiter
		File file2 = new File("CourseInfo.txt");
		Scanner studentInputFile2 = new Scanner(file2);
		
		while(studentInputFile2.hasNext())
		{
			// Read the next row from StudentInfo.txt
            String courseRow = studentInputFile2.nextLine();

			// Use split() to parse the row into id, name, and course
            String[] courseInfo = courseRow.split(",");
			
			if(course.equals(courseInfo[0]))
			{
				location = courseInfo[1] + " " + courseInfo[2];
				day = courseInfo[3];
				time = courseInfo[4];
				break;
			}
			
			else
			{
				System.out.println("No record of the course could be found");
				System.exit(0);
			}
            
		}
		
		studentInputFile2.close(); 
		scheduleWriter.println("Name: " + name + "\nCourse: " + course + "\nLocation: " + location + "\nDays and Times: " + day + " " + time);
		scheduleWriter.close();
		System.out.println("Your schedule has been created.");
		
    }
}