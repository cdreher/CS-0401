public class Label
{
	public static void main(String[] args)
	{
		System.out.println("\nName: Collin Dreher\nYear: Freshman\nMajor: Computer Science");
	}
}