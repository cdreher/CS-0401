import javax.swing.*;
import java.awt.event.*;

public class TaxCalculator extends JFrame
{
	private JPanel panel;
	private JLabel messageLabel;
	private JTextField totalSalesTextField;
	private JButton calcButton;
	private final int windowWidth = 300;
	private final int windowHeight = 100;
	private final double countyTax = 0.02;
	private final double stateTax = 0.04;
	
	public TaxCalculator()
	{
		setTitle("Tax Calculator");
		
		setSize(windowWidth, windowHeight);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		buildPanel();
		
		add(panel);
		
		setVisible(true);
	}
	
	private void buildPanel()
	{
		messageLabel = new JLabel("Enter the total sales for the month.");
		
		totalSalesTextField = new JTextField(10);
		
		calcButton = new JButton("Calculate");
		
		calcButton.addActionListener(new CalcButtonListener());
		
		panel = new JPanel();
		
		panel.add(messageLabel);
		panel.add(totalSalesTextField);
		panel.add(calcButton);
	}
	
	private class CalcButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String input;
			double countyTax, stateTax, totalTax;
			
			input = totalSalesTextField.getText();
			
			countyTax = Double.parseDouble(input) * .02;
			stateTax = Double.parseDouble(input) * .04;
			totalTax = countyTax + stateTax;
			
			JOptionPane.showMessageDialog(null, input + " total sales will yield a county sales tax of " + countyTax + " and a state sales tax of " + stateTax + "...adding to a total sales tax of " + totalTax);
		}
	}
}