public class BookDriver
{
	public static void main(String[] args)
	{
		Book b1 = new Book("Introduction to Computing Systems", "Yale Patt", "9780087463", "Computer Science", false, 2);
		Book b2 = new Book("Crime and Punishment", "Fyodor Dostoevsky", "9002322134", "Literature", true, 1);
		
		//Constructor 2
		b2.setTitle("Crime and Punishment");
		b2.setAuthor("Fyodor Dostoevsky");
		b2.setIsbn("9002322134");
		b2.setSubject("Literature");
		b2.setFiction(true);
		b2.setEditionNumber(1);
		
		System.out.println(b1);
		System.out.println();
		System.out.println(b2);
		
		if(b1.equals(b2))
			System.out.println("Books 1 and 2 are the same.");
		else
			System.out.println("Books 1 and 2 are not the same.");
		
		Book b3 = new Book("Essential Matlab for Engineers and Scientists", "Brian Hahn", "9883740001", "Engineering", false, 3);
		Book b4 = new Book(b3);
		
		System.out.println();
		System.out.println(b3);
		System.out.println();
		System.out.println(b4);
		
		if(b3.equals(b4))
			System.out.println("Books 3 and 4 are the same.");
		else
			System.out.println("Books 3 and 4 are not the same.");
		
		System.out.println();
		
		if(b2.getIsbn() == "9002322134")
			System.out.println("Book 2 and the book with the ISBN \"9002322134\" are the same.");
		else
			System.out.println("Book 2 and the book with the ISBN \"9002322134\" are not the same.");
		
		System.out.println();
		
		//Check to see if fiction, then output correct thing.
		if(b1.getFiction() == false)
			System.out.println(b1.getSubject());
		else
			System.out.println(b1.getEditionNumber());
		
		//Do the same for each of other books.
		if(b2.getFiction() == false)
			System.out.println(b2.getSubject());
		else
			System.out.println(b2.getEditionNumber());
		if(b3.getFiction() == false)
			System.out.println(b3.getSubject());
		else
			System.out.println(b3.getEditionNumber());
		if(b4.getFiction() == false)
			System.out.println(b4.getSubject());
		else
			System.out.println(b4.getEditionNumber());
		
	}
}