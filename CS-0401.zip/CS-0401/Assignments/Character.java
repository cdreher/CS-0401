/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment - Adventure Game (Second Revision)
*/

public abstract class Character
{
	String name = "";
	int hitPoints, strength;
	Weapon weapon;
	
	public Character(String name, int hitPoints, int strength, Weapon weapon)
	{
		this.name = name;
		this.hitPoints = hitPoints;
		this.strength = strength;
		this.weapon = weapon;
	}
	
	public String getName()
	{
		return name;
	}
	
	//Returns HP.
	public int getHitPoints()
	{
		return hitPoints;
	}
	
	//Returns strength.
	public int getStrength()
	{
		return strength;
	}
	
	//Increase HP by given amount.
	public void increaseHitPoints(int pointIncrease)
	{
		hitPoints += pointIncrease;
	}
	
	//Decrease HP by given amount.
	public void decreaseHitPoints(int pointDecrease)
	{
		hitPoints -= pointDecrease;
	}
	
	//Returns whether the player is still alive.
	public boolean isDefeated()
	{
		if(hitPoints <= 0)
			return true;
		return false;
	}
}