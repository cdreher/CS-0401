import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class PlayerPanel extends JPanel
{
	private JButton selectPlayer;
	private JLabel playerLabel;
	private JLabel weaponLabel;
	private JList playerList;
	private JList weaponList;
	private ImageIcon playerImage;
	private JButton button1;
	private ImageIcon weaponImage;
	private String[] players = { "Paladin", "Rogue", "Jackie Chan" };
	private String[] weapons = { "Mace", "Short Sword", "Long Sword", "Axe" };
	private String playerName = "";
	private String weaponName = "";
	private boolean isSelected = false;

	
	public PlayerPanel()
	{
		setLayout(new GridLayout(0,1,5,5));
		
		//Create lists.
		playerList = new JList(players);
		weaponList = new JList(weapons);
		
		//Register the list selection listeners.
		playerList.addListSelectionListener(new PlayerListSelectionListener());
		weaponList.addListSelectionListener(new WeaponListSelectionListener());
		
		//Set selection mode for lists.
		playerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		weaponList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	
		//Create two labels and button.
		playerLabel = new JLabel("Select a playable character.");
		weaponLabel = new JLabel("Select a weapon.");
		selectPlayer = new JButton("Select Player");
		
		//Add everything.
		add(playerList);
		add(playerLabel);
		add(weaponList);
		add(weaponLabel);
		add(selectPlayer);
		
		//Register the action listener.
		selectPlayer.addActionListener(new SelectPlayerListener());
		
		
	}
	
	public String getName()
	{
		return playerName;
	}
	
	public String getWeapon()
	{
		return weaponName;
	}
	
	public boolean isSelected()
	{
		return isSelected;
	}
	
	
	private class PlayerListSelectionListener implements ListSelectionListener
	{
		public void valueChanged(ListSelectionEvent e)
		{
			playerName = (String)playerList.getSelectedValue();
			
			if(playerName.equals("Paladin"))
			{
				playerImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Paladin.png");
				playerLabel.setText("");
				playerLabel.setIcon(playerImage);
			}
			else if(playerName.equals("Rogue"))
			{
				playerImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Rogue.png");
				playerLabel.setText("");
				playerLabel.setIcon(playerImage);
			}
			else
			{
				playerImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/JackieChan.png");
				playerLabel.setText("");
				playerLabel.setIcon(playerImage);
			}
			
		}
	}
	
	private class WeaponListSelectionListener implements ListSelectionListener
	{
		public void valueChanged(ListSelectionEvent e)
		{
			weaponName = (String)weaponList.getSelectedValue();
			
			if(weaponName.equals("Mace"))
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Mace.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
			else if(weaponName.equals("Short Sword"))
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/ShortSword.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
			else if(weaponName.equals("Long Sword"))
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/LongSword.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
			else
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Axe.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
		}
	}
	
	private class SelectPlayerListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			weaponName = (String)weaponList.getSelectedValue();
			playerName = (String)playerList.getSelectedValue();
			
			if(playerName == null && weaponName == null)
			{
				JOptionPane.showMessageDialog(null, "ERROR: You must select a character and a weapon.", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			else if(playerName == null)
				JOptionPane.showMessageDialog(null, "ERROR: You must select a character.", "Player Selection", JOptionPane.ERROR_MESSAGE);
			else if(weaponName == null)
				JOptionPane.showMessageDialog(null, "ERROR: You must select a weapon.", "Weapon Selection", JOptionPane.ERROR_MESSAGE);
			else
			{
				isSelected = true;
				selectPlayer.setEnabled(false);
				playerList.setEnabled(false);
				weaponList.setEnabled(false);
				
			}
		}
		
	}
}