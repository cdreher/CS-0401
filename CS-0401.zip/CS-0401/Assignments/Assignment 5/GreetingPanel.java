import javax.swing.*;

public class GreetingPanel extends JPanel
{
   private JLabel greeting; 

   public GreetingPanel()
   {
      // Create the label.
      greeting = new JLabel("Adventure Game Battle Simulator");

      // Add the label to this panel.
      add(greeting);
   }
}