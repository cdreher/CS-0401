public class Assignment5
{
	public static void main(String[] args)
	{
		BattleSimulator b = new BattleSimulator();
	}
}