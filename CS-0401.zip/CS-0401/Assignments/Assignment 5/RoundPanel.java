import javax.swing.*;
import java.awt.*;

public class RoundPanel extends JPanel
{
	private JRadioButton fiveRounds;
	private JRadioButton twentyFiveRounds;
	private JRadioButton fiftyRounds;
	private JRadioButton hundredRounds;
	private ButtonGroup bg;
	
	public RoundPanel()
	{
		setLayout(new GridLayout(4,1));
		
		fiveRounds = new JRadioButton("5 rounds", true);
		twentyFiveRounds = new JRadioButton("25 rounds");
		fiftyRounds = new JRadioButton("50 rounds");
		hundredRounds = new JRadioButton("100 rounds");
		
		bg = new ButtonGroup();
		bg.add(fiveRounds);
		bg.add(twentyFiveRounds);
		bg.add(fiftyRounds);
		bg.add(hundredRounds);
		
		setBorder(BorderFactory.createTitledBorder("Num Rounds"));
		
		add(fiveRounds);
		add(twentyFiveRounds);
		add(fiftyRounds);
		add(hundredRounds);
	}
	
	public int getNumRounds()
	{
		int numRounds = 0;
		
		if(fiveRounds.isSelected())
			numRounds = 5;
		else if(twentyFiveRounds.isSelected())
			numRounds = 25;
		else if(fiftyRounds.isSelected())
			numRounds = 50;
		else
			numRounds = 100;
		
		return numRounds;
	}
}