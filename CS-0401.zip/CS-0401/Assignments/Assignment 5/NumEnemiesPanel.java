import javax.swing.*;
import java.awt.*;

public class NumEnemiesPanel extends JPanel
{
	private JRadioButton fourEnemies;
	private JRadioButton fiveEnemies;
	private JRadioButton sixEnemies;
	private ButtonGroup bg;
	
	public NumEnemiesPanel()
	{
		setLayout(new GridLayout(3,1));
		
		fourEnemies = new JRadioButton("4 enemies", true);
		fiveEnemies = new JRadioButton("5 enemies");
		sixEnemies = new JRadioButton("6 enemies");
		
		bg = new ButtonGroup();
		bg.add(fourEnemies);
		bg.add(fiveEnemies);
		bg.add(sixEnemies);
		
		setBorder(BorderFactory.createTitledBorder("Num Enemies"));
		
		add(fourEnemies);
		add(fiveEnemies);
		add(sixEnemies);
	}
	
	public int getNumEnemies()
	{
		int numEnemies = 0;
		
		if(fourEnemies.isSelected())
			numEnemies = 4;
		else if(fiveEnemies.isSelected())
			numEnemies = 5;
		else
			numEnemies = 6;
		
		return numEnemies;
	}
}