import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class EnemyPanel extends JPanel
{
	private JButton selectEnemy;
	private JLabel enemyLabel;
	private JLabel weaponLabel;
	private JList enemyList;
	private JList weaponList;
	private ImageIcon enemyImage;
	private ImageIcon weaponImage;
	private String[] enemies = { "Goblin", "Skeleton" };
	private String[] weapons = { "Mace", "Short Sword", "Long Sword", "Axe" };
	private String enemyName = "";
	private String weaponName = "";
	private boolean isSelected = false;
	
	public EnemyPanel()
	{
		setLayout(new GridLayout(0,1,5,5));
		
		//Create lists.
		enemyList = new JList(enemies);
		weaponList = new JList(weapons);
		
		//Register the list selection listeners.
		enemyList.addListSelectionListener(new EnemyListSelectionListener());
		weaponList.addListSelectionListener(new WeaponListSelectionListener());
		
		//Set selection mode for lists.
		enemyList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		weaponList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	
		//Create two labels and button.
		enemyLabel = new JLabel("Select a playable character.");
		weaponLabel = new JLabel("Select a weapon.");
		selectEnemy = new JButton("Select Enemy");
		
		//Add everything.
		add(enemyList);
		add(enemyLabel);
		add(weaponList);
		add(weaponLabel);
		add(selectEnemy);
		
		//Register the action listener.
		selectEnemy.addActionListener(new SelectEnemyListener());
		
		
	}
	
	public String getName()
	{
		return enemyName;
	}
	
	public String getWeapon()
	{
		return weaponName;
	}
	
	public boolean isSelected()
	{
		return isSelected;
	}
	
	
	
	private class EnemyListSelectionListener implements ListSelectionListener
	{
		public void valueChanged(ListSelectionEvent e)
		{
			enemyName = (String)enemyList.getSelectedValue();
			
			if(enemyName.equals("Goblin"))
			{
				enemyImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Goblin.png");
				enemyLabel.setText("");
				enemyLabel.setIcon(enemyImage);
			}
			else
			{
				enemyImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Skeleton.png");
				enemyLabel.setText("");
				enemyLabel.setIcon(enemyImage);
			}
			
			
		}
	}
	
	private class WeaponListSelectionListener implements ListSelectionListener
	{
		public void valueChanged(ListSelectionEvent e)
		{
			weaponName = (String)weaponList.getSelectedValue();
			
			if(weaponName.equals("Mace"))
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Mace.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
			else if(weaponName.equals("Short Sword"))
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/ShortSword.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
			else if(weaponName.equals("Long Sword"))
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/LongSword.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
			else
			{
				weaponImage = new ImageIcon("C:/Users/Collin Dreher/Desktop/CS-0401/Assignments/Assignment 5/Axe.png");
				weaponLabel.setText("");
				weaponLabel.setIcon(weaponImage);
			}
		}
	}
	
	private class SelectEnemyListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			weaponName = (String)weaponList.getSelectedValue();
			enemyName = (String)enemyList.getSelectedValue();
			
			if(enemyName == null && weaponName == null)
			{
				JOptionPane.showMessageDialog(null, "ERROR: You must select a character and a weapon.", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			else if(enemyName == null)
				JOptionPane.showMessageDialog(null, "ERROR: You must select a character.", "Character Selection", JOptionPane.ERROR_MESSAGE);
			else if(weaponName == null)
				JOptionPane.showMessageDialog(null, "ERROR: You must select a weapon.", "Weapon Selection", JOptionPane.ERROR_MESSAGE);
			else
			{
				isSelected = true;
				selectEnemy.setEnabled(false);
				enemyList.setEnabled(false);
				weaponList.setEnabled(false);
				
			}
		}
		
	}
	
	
}