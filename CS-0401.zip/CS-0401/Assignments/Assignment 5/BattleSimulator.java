import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;


/*
Collin Dreher
CS-0401
Fall Semester 2015
Adventure Game - Assignment 5
*/

public class BattleSimulator extends JFrame
{
	private NumEnemiesPanel numEnemies;
	private RoundPanel rounds;
	private PlayerPanel player;
	private EnemyPanel enemy;
	private GreetingPanel greeting;
	private JPanel east;
	private JPanel buttonPanel;
	private JButton runBattlesButton;
	private JButton exitButton;
	private String playerName, enemyName, playerWeapon, enemyWeapon;
	private int characterHP = 0;
	private int characterStrength = 0;
	private int characterMinWeapon = 0;
	private int characterMaxWeapon = 0;
	private int enemyATK = 0;
	private int characterATK = 0;
	private int enemyHP = 0;
	private int enemyStrength = 0;
	private int enemyMinWeapon = 0;
	private int enemyMaxWeapon = 0;
	private int enemies = 0;
	private int numRounds = 0;
	private int enemiesDefeated = 0;
	private int battlesWon = 0;
	private int battlesLost = 0;
	
	
	
	public BattleSimulator()
	{
		setTitle("CS401: Assignment 5");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout(50, 20));
		
		rounds = new RoundPanel();
		numEnemies = new NumEnemiesPanel();
		player = new PlayerPanel();
		enemy = new EnemyPanel();
		greeting = new GreetingPanel();
		
		east = new JPanel(new GridLayout(0,1,5,5));
		east.add(numEnemies);
		east.add(rounds);
		
		buildButtonPanel();
		
		add(east, BorderLayout.EAST);
		add(enemy, BorderLayout.CENTER);
		add(player, BorderLayout.WEST);
		add(buttonPanel, BorderLayout.SOUTH);
		add(greeting, BorderLayout.NORTH);
		
		pack();
		setVisible(true);
		
	}
	
	private void buildButtonPanel()
	{
		buttonPanel = new JPanel();
		
		runBattlesButton = new JButton("Run Battles");
		exitButton = new JButton("Exit");
		
		runBattlesButton.addActionListener(new RunBattlesButtonListener());
		exitButton.addActionListener(new ExitButtonListener());
		
		buttonPanel.add(runBattlesButton);
		buttonPanel.add(exitButton);
	}
	
	private class RunBattlesButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			if(player.isSelected() && enemy.isSelected())
			{
				playerName = player.getName();
				enemyName = enemy.getName();
				playerWeapon = player.getWeapon();
				enemyWeapon = enemy.getWeapon();
				enemies = numEnemies.getNumEnemies();
				numRounds = rounds.getNumRounds();
				
				if(playerName.equals("Paladin"))
				{
					characterHP = 30;
					characterStrength = 12;
				}
				else if(playerName.equals("Rogue"))
				{
					characterHP = 50;
					characterStrength = 7;
				}
				else
				{
					characterHP = 40;
					characterStrength = 10;
				}
				
				if(playerWeapon.equals("Mace"))
				{
					characterMinWeapon = 3;
					characterMaxWeapon = 6;
				}
				else if(playerWeapon.equals("Short Sword"))
				{
					characterMinWeapon = 1;
					characterMaxWeapon = 4;
				}
				else if(playerWeapon.equals("Long Sword"))
				{
					characterMinWeapon = 3;
					characterMaxWeapon = 7;
				}
				else
				{
					characterMinWeapon = 2;
					characterMaxWeapon = 6;
				}
				
				if(enemyName.equals("Goblin"))
				{
					enemyHP = 25;
					enemyStrength = 4;
				}
				else
				{
					enemyHP = 25;
					enemyStrength = 3;
				}
				
				if(enemyWeapon.equals("Mace"))
				{
					enemyMinWeapon = 3;
					enemyMaxWeapon = 6;
				}
				else if(enemyWeapon.equals("Short Sword"))
				{
					enemyMinWeapon = 1;
					enemyMaxWeapon = 4;
				}
				else if(enemyWeapon.equals("Long Sword"))
				{
					enemyMinWeapon = 3;
					enemyMaxWeapon = 7;
				}
				else
				{
					enemyMinWeapon = 2;
					enemyMaxWeapon = 6;
				}
				
				for(int i = 0; i < numRounds; i++)
				{
					Random r = new Random();
					
					
					for(int j = 0; j < enemies; j++)
					{
						
						while(characterHP > 0 && enemyHP > 0)
						{
							
							characterATK = characterStrength + characterMinWeapon + r.nextInt(characterMaxWeapon - characterMinWeapon + 1);
							
							enemyATK = enemyStrength + enemyMinWeapon + r.nextInt(enemyMaxWeapon - enemyMinWeapon + 1);
						
							enemyHP -= characterATK;
					
							//Decrease the user's HP only if the Goblin is still alive.
							if(enemyHP > 0)
								characterHP -= enemyATK;
							
							//Reset the Goblin HP for each new Goblin.
							if(enemyHP <= 0)
							{
								enemiesDefeated++;
								break;
								
							}
							if(characterHP <= 0)
							{
								battlesLost++;
								break;
							}
						}
						if(characterHP > 0)
						{
							battlesWon++;
						}
					
					}
		
					enemyHP = 25;
					
					if(playerName.equals("Paladin"))
						characterHP = 30;
					else if(playerName.equals("Rogue"))
						characterHP = 50;
					else
						characterHP = 40;
				}
				
				JOptionPane.showMessageDialog(null, getPanel(), "Simulation Results", JOptionPane.INFORMATION_MESSAGE); 
				System.exit(0);
			}				
			else
				JOptionPane.showMessageDialog(null, "ERROR: You must select a player and an enemy.", "Run Battles", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private JPanel getPanel()
	{
		JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
		JLabel enemiesLabel = new JLabel("Number of enemies per round: " + enemies);
		JLabel roundsLabel = new JLabel("Number of rounds: " + numRounds);
		JLabel battlesWonLabel = new JLabel("Number of battles won: " + battlesWon);
		JLabel battlesLostLabel = new JLabel("Number of battles lost: " + battlesLost);
		JLabel totalEnemiesLabel = new JLabel("Total number of enemies defeated: " + enemiesDefeated);
		panel.add(enemiesLabel);
		panel.add(roundsLabel);
		panel.add(battlesWonLabel);
		panel.add(battlesLostLabel);
		panel.add(totalEnemiesLabel);
		
		return panel;
		
	}
	
	private class ExitButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			System.exit(0);
		}
	}
}
