/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment 2 - Adventure Game
*/

import java.util.Scanner;
import java.util.Random;

public class AdventureGame
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		int characterHP;
		int characterStrength;
		int characterWeapon;
		int enemyHP;
		int enemyStrength;
		int enemyWeapon;
		int characterATK;
		int enemyATK;
		
		//Prompt the user to choose one character, and then store that specific character.
		System.out.println("Welcome to the Adventure Game. Here marks the beginning of your journey!");
		System.out.println("Here are the characters:\n1. Rogue\n2. Paladin\n3. Jackie Chan\n");
		System.out.print("Which character would you like to choose?:\n");
		int character = keyboard.nextInt();
		
		//Provide each character with their corresponding HP and strength attributes.
		if(character == 1)
		{
			System.out.println("You chose: Rogue\n");
			characterHP = 50;
			characterStrength = 7;
		}
		else if(character == 2)
		{
			System.out.println("You chose: Paladin\n");
			characterHP = 30;
			characterStrength = 12;
		}
		else
		{
			System.out.println("You chose: Jackie Chan\n");
			characterHP = 40;
			characterStrength = 10;
		}
		
		//Prompt the user to choose a path to go down.
		System.out.println("The Evil Wizard must be defeated! He is in The Castle. To get to The Castle, you must travel through either:\n\n1. The Forest\n2. The Graveyard\n");
		System.out.print("Which path would you like to choose?:\n");
		int path = keyboard.nextInt();
		
		if(character == 1)
		{
			if(path == 1)
			{
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter 3 Goblins! Time for battle!");
				int enemies = 1;
				enemyHP = 25;
				enemyStrength = 4;
				
				//Pass through the loop three times, resetting the goblin HP to 25, assuming the user stays alive.
				for(int i = 0; i < 3; i++)
				{
					System.out.println("***Rogue vs. Goblin " + enemies + "***");
					characterWeapon = r.nextInt(4) + 1;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(5) + 2;
					enemyATK = enemyStrength + enemyWeapon;
					
					//Decrease the Goblin's HP accordingly, provided the user still has HP remaining.
					if(characterHP > 0)
					{
						System.out.println("Rogue attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Goblin HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					//Decrease the user's HP only if the Goblin is still alive.
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nGoblin attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Rogue HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					//Reset the Goblin HP for each new Goblin.
					if(enemyHP <= 0)
					{
						System.out.println("Rogue defeated Goblin " + enemies + "!\n");
						enemies++;
						enemyHP = 25;
					}
					//Terminate the program if the user has no HP remaining.
					if(characterHP <= 0)
					{
						System.out.println("Rogue is defeated by Goblin " + enemies + "!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
			else
			{
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter 5 Skeletons! Time for battle!");
				int enemies = 1;
				enemyHP = 25;
				enemyStrength = 3;
			
				for(int i = 0; i < 5; i++)
				{
					System.out.println("***Rogue vs. Skeleton " + enemies + "***");
					characterWeapon = r.nextInt(4) + 1;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(4) + 1;
					enemyATK = enemyStrength + enemyWeapon;
					if(characterHP > 0)
					{
						System.out.println("Rogue attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Skeleton HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nSkeleton attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Rogue HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Rogue defeated Skeleton " + enemies + "!\n");
						enemies++;
						enemyHP = 25;
					}
					if(characterHP <= 0)
					{
						System.out.println("Rogue is defeated by Skeleton " + enemies + "!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
			
			System.out.println("Your HP is: " + characterHP);
			System.out.println("\nPlease choose a reward:\n1. Healing Potion\n2. Ring of Strength");
			int reward = keyboard.nextInt();
			
			//For each reward, change the user's attributes accordingly.
			if(reward == 1)
			{
				System.out.println("You chose: Healing Potion");
				System.out.println("\nYour HP has increased " + characterHP + " + 10 = " + (characterHP + 10));
				characterHP += 10;
			}
			else
			{
				System.out.println("You chose: Ring of Strength");
				System.out.println("\nYour strength has increased " + characterStrength + " + 5 = " + (characterStrength + 5));
				characterStrength += 5;
			}
			
			System.out.println("You have reached The Castle! Time to battle The Evil Wizard!");
			System.out.println("***Rogue vs. The Evil Wizard***");
			int spellCast = r.nextInt(5) + 1;
			
			enemyHP = 40;
			enemyStrength = 8;
			
			while(characterHP > 0 && enemyHP > 0)
			{
				System.out.println("Choose your action:\n1. Attack\n2. Attempt Spell Cast");
				int action = keyboard.nextInt();
				
				if(action == 1)
				{
					System.out.println("***Rogue vs. Evil Wizard***");
					characterWeapon = r.nextInt(4) + 1;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(7) + 4;
					enemyATK = enemyStrength + enemyWeapon;
					if(characterHP > 0)
					{
						System.out.println("Rogue attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Evil Wizard HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nEvil Wizard attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Rogue HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Rogue defeated Evil Wizard!\n\nYou win! Congrats!");
						System.exit(0);
					}
					if(characterHP <= 0)
					{
						System.out.println("Rogue is defeated by Evil Wizard!\n\nGAME OVER");
						System.exit(0);
					}
				}
				else
				{
					System.out.print("Enter your guess:");
					int guess = keyboard.nextInt();
					
					//If the user guesses correctly, the Evil Wizard's HP evaporates, and the game terminates.
					if(guess == spellCast)
					{
						System.out.println("Correct!\n\nRogue's spell is cast successfully! The Wizard's HP is now 0! You win! Congrats!");
						enemyHP = 0;
					}
					
					//If the user does not guess correctly, then they lose a turn, resulting in a lowered HP.
					else
					{
						System.out.println("\nSorry, your guess is not correct. You just wasted a turn.\n");
						characterWeapon = r.nextInt(4) + 1;
						characterATK = characterStrength + characterWeapon;
						enemyWeapon = r.nextInt(7) + 4;
						enemyATK = enemyStrength + enemyWeapon;
						System.out.println("\nEvil Wizard attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Rogue HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
						if(characterHP <= 0)
						{
							System.out.println("Rogue is defeated by Evil Wizard!\n\nGAME OVER");
							System.exit(0);
						}
					}
				}
			}	
			
		}
		
		else if(character == 2)
		{
			if(path == 1)
			{
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter 3 Goblins! Time for battle!");
				int enemies = 1;
				enemyHP = 25;
				enemyStrength = 4;
			
				for(int i = 0; i < 3; i++)
				{
					System.out.println("***Paladin vs. Goblin " + enemies + "***");
					characterWeapon = r.nextInt(5) + 3;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(5) + 2;
					enemyATK = enemyStrength + enemyWeapon;
					if(characterHP > 0)
					{
						System.out.println("Paladin attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Goblin HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nGoblin attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Paladin HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Paladin defeated Goblin " + enemies + "!\n");
						enemies++;
						enemyHP = 25;
					}
					if(characterHP <= 0)
					{
						System.out.println("Paladin is defeated by Goblin " + enemies + "!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
			else
			{
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter 5 Skeletons! Time for battle!");
				int enemies = 1;
				enemyHP = 25;
				enemyStrength = 3;
			
				for(int i = 0; i < 5; i++)
				{
					System.out.println("***Paladin vs. Skeleton " + enemies + "***");
					characterWeapon = r.nextInt(5) + 3;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(4) + 1;
					enemyATK = enemyStrength + enemyWeapon;
					if(characterHP > 0)
					{
						System.out.println("Paladin attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Skeleton HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nSkeleton attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Paladin HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Paladin defeated Skeleton " + enemies + "!\n");
						enemies++;
						enemyHP = 25;
					}
					if(characterHP <= 0)
					{
						System.out.println("Paladin is defeated by Skeleton " + enemies + "!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
			
			System.out.println("Your HP is: " + characterHP);
			System.out.println("\nPlease choose a reward:\n1. Healing Potion\n2. Ring of Strength");
			int reward = keyboard.nextInt();
			
			if(reward == 1)
			{
				System.out.println("You chose: Healing Potion");
				System.out.println("\nYour HP has increased " + characterHP + " + 10 = " + (characterHP + 10));
				characterHP += 10;
			}
			else
			{
				System.out.println("You chose: Ring of Strength");
				System.out.println("\nYour strength has increased " + characterStrength + " + 5 = " + (characterStrength + 5));
				characterStrength += 5;
			}
			
			System.out.println("You have reached The Castle! Time to battle The Evil Wizard!");
			System.out.println("***Paladin vs. The Evil Wizard***");
			int spellCast = r.nextInt(5) + 1;
			
			enemyHP = 40;
			enemyStrength = 8;
			
			while(characterHP > 0 && enemyHP > 0)
			{
				System.out.println("Choose your action:\n1. Attack\n2. Attempt Spell Cast");
				int action = keyboard.nextInt();
				
				if(action == 1)
				{
					System.out.println("***Paladin vs. Evil Wizard***");
					characterWeapon = r.nextInt(5) + 3;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(7) + 4;
					enemyATK = enemyStrength + enemyWeapon;
					if(characterHP > 0)
					{
						System.out.println("Paladin attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Evil Wizard HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nEvil Wizard attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Paladin HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Paladin defeated Evil Wizard!\n\nYou win! Congrats!");
						System.exit(0);
					}
					if(characterHP <= 0)
					{
						System.out.println("Paladin is defeated by Evil Wizard!\n\nGAME OVER");
						System.exit(0);
					}
				}
				else
				{
					System.out.print("Enter your guess:");
					int guess = keyboard.nextInt();
					
					if(guess == spellCast)
					{
						System.out.println("Correct!\n\nPaladin's spell is cast successfully! The Wizard's HP is now 0! You win! Congrats!");
						enemyHP = 0;
					}
					else
					{
						System.out.println("\nSorry, your guess is not correct. You just wasted a turn.\n");
						characterWeapon = r.nextInt(5) + 3;
						characterATK = characterStrength + characterWeapon;
						enemyWeapon = r.nextInt(7) + 4;
						enemyATK = enemyStrength + enemyWeapon;
						System.out.println("\nEvil Wizard attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Paladin HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
						if(characterHP <= 0)
						{
							System.out.println("Paladin is defeated by Evil Wizard!\n\nGAME OVER");
							System.exit(0);
						}
					}
				}
			}
		}	
		
		else
		{
			if(path == 1)
			{
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter 3 Goblins! Time for battle!");
				int enemies = 1;
				enemyHP = 25;
				enemyStrength = 4;
			
				for(int i = 0; i < 3; i++)
				{
					System.out.println("***Jackie Chan vs. Goblin " + enemies + "***");
					characterWeapon = r.nextInt(5) + 2;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(5) + 2;
					enemyATK = enemyStrength + enemyWeapon;
					if(characterHP > 0)
					{
						System.out.println("Jackie Chan attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Goblin HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nGoblin attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Jackie Chan HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Jackie Chan defeated Goblin " + enemies + "!\n");
						enemies++;
						enemyHP = 25;
					}
					if(characterHP <= 0)
					{
						System.out.println("Jackie Chan is defeated by Goblin " + enemies + "!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
			else
			{
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter 5 Skeletons! Time for battle!");
				int enemies = 1;
				enemyHP = 25;
				enemyStrength = 3;
			
				for(int i = 0; i < 5; i++)
				{
					System.out.println("***Jackie Chan vs. Skeleton " + enemies + "***");
					characterWeapon = r.nextInt(5) + 2;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(4) + 1;
					enemyATK = enemyStrength + enemyWeapon;
					
					if(characterHP > 0)
					{
						System.out.println("Jackie Chan attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Skeleton HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nSkeleton attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Jackie Chan HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Jackie Chan defeated Skeleton " + enemies + "!\n");
						enemies++;
						enemyHP = 25;
					}
					if(characterHP <= 0)
					{
						System.out.println("Jackie Chan is defeated by Skeleton " + enemies + "!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
			
			System.out.println("Your HP is: " + characterHP);
			System.out.println("\nPlease choose a reward:\n1. Healing Potion\n2. Ring of Strength");
			int reward = keyboard.nextInt();
			
			if(reward == 1)
			{
				System.out.println("You chose: Healing Potion");
				System.out.println("\nYour HP has increased " + characterHP + " + 10 = " + (characterHP + 10));
				characterHP += 10;
			}
			else
			{
				System.out.println("You chose: Ring of Strength");
				System.out.println("\nYour strength has increased " + characterStrength + " + 5 = " + (characterStrength + 5));
				characterStrength += 5;
			}
			
			System.out.println("You have reached The Castle! Time to battle The Evil Wizard!");
			System.out.println("***Jackie Chan vs. The Evil Wizard***");
			int spellCast = r.nextInt(5) + 1;
			
			enemyHP = 40;
			enemyStrength = 8;
			
			while(characterHP > 0 && enemyHP > 0)
			{
				System.out.println("Choose your action:\n1. Attack\n2. Attempt Spell Cast");
				int action = keyboard.nextInt();
				
				if(action == 1)
				{
					System.out.println("***Jackie Chan vs. Evil Wizard***");
					characterWeapon = r.nextInt(5) + 2;
					characterATK = characterStrength + characterWeapon;
					enemyWeapon = r.nextInt(7) + 4;
					enemyATK = enemyStrength + enemyWeapon;
					
					if(characterHP > 0)
					{
						System.out.println("Jackie Chan attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
						System.out.println("Evil Wizard HP is now " + enemyHP + " - " + characterATK + " = " + (enemyHP - characterATK));
						enemyHP -= characterATK;
					}
					if(characterHP > 0 && enemyHP > 0)
					{
						System.out.println("\nEvil Wizard attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Jackie Chan HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
					}
					if(enemyHP <= 0)
					{
						System.out.println("Jackie Chan defeated Evil Wizard!\n\nYou win! Congrats!");
						System.exit(0);
					}
					if(characterHP <= 0)
					{
						System.out.println("Jackie Chan is defeated by Evil Wizard!\n\nGAME OVER");
						System.exit(0);
					}
				}
				else
				{
					System.out.print("Enter your guess:");
					int guess = keyboard.nextInt();
					
					if(guess == spellCast)
					{
						System.out.println("Correct!\n\nJackie Chan's spell is cast successfully! The Wizard's HP is now 0! You win! Congrats!");
						enemyHP = 0;
					}
					else
					{
						System.out.println("\nSorry, your guess is not correct. You just wasted a turn.\n");
						characterWeapon = r.nextInt(5) + 2;
						characterATK = characterStrength + characterWeapon;
						enemyWeapon = r.nextInt(7) + 4;
						enemyATK = enemyStrength + enemyWeapon;
						System.out.println("\nEvil Wizard attacks with ATK = " + enemyStrength + " + " + enemyWeapon + " = " + enemyATK);
						System.out.println("Jackie Chan HP is now " + characterHP + " - " + enemyATK + " = " + (characterHP - enemyATK) + "\n");
						characterHP -= enemyATK;
						if(characterHP <= 0)
						{
							System.out.println("Jackie Chan is defeated by Evil Wizard!\n\nGAME OVER");
							System.exit(0);
						}
					}
				}
			}
		}
	}
}