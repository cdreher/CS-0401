/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment 4 - Adventure Game (Second Revision)
*/

import java.util.Scanner;
import java.util.Random;

public class AdventureGameV3
{	
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		
		
		//Welcome the user to the game, and then get their character.
		System.out.println("Welcome to the Adventure Game. Here marks the beginning of your journey!");
		int character = getCharacter();
		
		//Provide each character with their corresponding HP and strength attributes.
		if(character == 1)
		{
			//Creates new weapon and player objects.
			Weapon w = new Weapon("Short Sword", Weapon.rogueMin, Weapon.rogueMax);
			Player p = new Player("Rogue", 50, 7, w);
			System.out.println("You chose: " + p.getName() + "\n");
			
			if(getPath() == 1)
			{
				Weapon wEnemy = new Weapon("Mace", Weapon.goblinMin, Weapon.goblinMax);
				Enemy e = new Enemy("Goblin", 25, 4, wEnemy);
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter " + e.getNumGoblins() + " Goblins! Time for battle!");
				
				//Calls battle method.
				p.battleMinion(e);
				//Calls item shop method following the battle.
				ItemShop.visitItemShop(p);
				
			}
			else
			{
				Weapon wEnemy = new Weapon("Short Sword", Weapon.skeletonMin, Weapon.skeletonMax);
				Enemy e = new Enemy("Skeleton", 25, 3, wEnemy);
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter " + e.getNumSkeletons() + " Skeletons! Time for battle!");
				
				p.battleMinion(e);
				ItemShop.visitItemShop(p);		
			}
			
			System.out.println("Your HP is: " + p.getHitPoints());
			
			Weapon wWizard = new Weapon("Fire Blast", Weapon.wizardMin, Weapon.wizardMax);
			Enemy wizard = new Enemy("Evil Wizard", 40, 8, wWizard);
			
			p.battleWizard(wizard);
		
			
		}
		else if(character == 2)
		{
			Weapon w = new Weapon("Long Sword", Weapon.paladinMin, Weapon.paladinMax);
			Player p = new Player("Paladin", 30, 12, w);
			System.out.println("You chose: " + p.getName() + "\n");
			
			if(getPath() == 1)
			{
				Weapon wEnemy = new Weapon("Mace", Weapon.goblinMin, Weapon.goblinMax);
				Enemy e = new Enemy("Goblin", 25, 4, wEnemy);
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter " + e.getNumGoblins() + " Goblins! Time for battle!");
				
				p.battleMinion(e);
				ItemShop.visitItemShop(p);
				
			}
			else
			{
				Weapon wEnemy = new Weapon("Short Sword", Weapon.skeletonMin, Weapon.skeletonMax);
				Enemy e = new Enemy("Skeleton", 25, 3, wEnemy);
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter " + e.getNumSkeletons() + "Skeletons! Time for battle!");
				
				p.battleMinion(e);
				ItemShop.visitItemShop(p);		
			}
			
			System.out.println("Your HP is: " + p.getHitPoints());
			
			Weapon wWizard = new Weapon("Fire Blast", Weapon.wizardMin, Weapon.wizardMax);
			Enemy wizard = new Enemy("Evil Wizard", 40, 8, wWizard);
			
			p.battleWizard(wizard);
		}
		else
		{
			Weapon w = new Weapon("Mace", Weapon.jackieChanMin, Weapon.jackieChanMax);
			Player p = new Player("Jackie Chan", 40, 10, w);
			System.out.println("You chose: " + p.getName() + "\n");
			
			if(getPath() == 1)
			{
				Weapon wEnemy = new Weapon("Mace", Weapon.goblinMin, Weapon.goblinMax);
				Enemy e = new Enemy("Goblin", 25, 4, wEnemy);
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter " + e.getNumGoblins() + " Goblins! Time for battle!");
				
				p.battleMinion(e);
				ItemShop.visitItemShop(p);
				
			}
			else
			{
				Weapon wEnemy = new Weapon("Short Sword", Weapon.skeletonMin, Weapon.skeletonMax);
				Enemy e = new Enemy("Skeleton", 25, 3, wEnemy);
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter " + e.getNumSkeletons() + "Skeletons! Time for battle!");
				
				p.battleMinion(e);
				ItemShop.visitItemShop(p);		
			}
			
			System.out.println("Your HP is: " + p.getHitPoints());
			
			Weapon wWizard = new Weapon("Fire Blast", Weapon.wizardMin, Weapon.wizardMax);
			Enemy wizard = new Enemy("Evil Wizard", 40, 8, wWizard);
			
			//Calls wizard battle.
			p.battleWizard(wizard);
		}
		
		
	}
	
	//Returns character name (due to integer entered by the user).
	public static int getCharacter()
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Here are the characters:\n1. Rogue\n2. Paladin\n3. Jackie Chan\n");
		System.out.print("Which character would you like to choose?:\n");
		return keyboard.nextInt();
	}
	
	//Returns path of character.
	public static int getPath()
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("The Evil Wizard must be defeated! He is in The Castle. To get to The Castle, you must travel through either:\n\n1. The Forest\n2. The Graveyard\n");
		System.out.print("Which path would you like to choose?:\n");
		return keyboard.nextInt();
	}
	
}