/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment - Adventure Game (Second Revision)
*/

import java.util.Random;
import java.util.Scanner;

public class ItemShop
{
	private static final int longSwordPrice = 120;
	private static final int shortSwordPrice = 90;
	private static final int macePrice = 80;
	private static final int ringOfStrengthPrice = 150;
	private static final int healingPotionPrice = 10;
	
	
	
	public static void visitItemShop(Player player)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		int itemNumber, itemQuantity, totalCost, discount, finalCost;
		
		System.out.print("Would you like to visit the Item Shop?\nEnter 1 for \"yes\" or 0 for \"no\":");
		int continuePurchase = keyboard.nextInt();
		
		if(continuePurchase == 1)
		{
			do{
				//Welcome the user to the Item Shop and display all items and their prices.
				System.out.println("Welcome to The Item Shop!");
				System.out.println("You currently have " + player.getCoins() + " gold.");
				System.out.println("\nHere's what we have for sale (all prices are in units of gold):\n1. Long Sword\t" + longSwordPrice + "\n2. Short Sword\t" + shortSwordPrice + "\n3. Mace\t" + macePrice + "\n4. Ring Of Strengh\t" + ringOfStrengthPrice + "\n5. Healing Potion\t" + healingPotionPrice);
				
				//Prompt the user to choose an item, and then store it.
				System.out.println("Please enter the item number:");
				itemNumber = keyboard.nextInt();
				
				//Prompt the user to enter the quantity of the item they chose, and then store it.
				System.out.println("Please enter the quantity:");
				itemQuantity = keyboard.nextInt();
				
				int price;
				
				//Specify item name and price to long sword.
				if(itemNumber == 1)
				{
					price = longSwordPrice;
					if(itemQuantity > 1)
					{
						System.out.println("You may only purchase one of this item. I will change your quantity request to one!");
						itemQuantity = 1;
					}
				}
				
				//Specify item name and price to short sword.
				else if(itemNumber == 2)
				{
					price = shortSwordPrice;
					if(itemQuantity > 1)
					{
						System.out.println("You may only purchase one of this item. I will change your quantity request to one!");
						itemQuantity = 1;
					}
				}
				
				//Specify item name and price to mace.
				else if(itemNumber == 3)
				{
					price = macePrice;
					if(itemQuantity > 1)
					{
						System.out.println("You may only purchase one of this item. I will change your quantity request to one!");
						itemQuantity = 1;
					}
				}
				
				//Specify item name and price to Ring of Strength.
				else if(itemNumber == 4)
				{
					price = ringOfStrengthPrice;
				}
				
				//Specify item name and price to healing potion.
				else
				{
					price = healingPotionPrice;
				}
					
				//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
				if(itemQuantity >= 3)
				{
					totalCost = price * itemQuantity;
					discount = totalCost / 10;
					finalCost = totalCost - discount;
				}
				//Otherwise, calculate the total and final costs.
				else
				{
					totalCost = price * itemQuantity;
					discount = 0;
					finalCost = totalCost;
				}
				
				//If the user does not have sufficient funds, prompt them to come back later.
				if(finalCost > player.getCoins())
				{
					System.out.println("Your purchase cannot be completed! You don't have enough gold coins!");
					System.out.print("\nWould you like to make another purchase?\nEnter 1 for \"yes\" or 0 for \"no\":");
					continuePurchase = keyboard.nextInt();
				}
				
				//Otherwise, display all of the information to the user.
				else
				{
					//Determine how many gold coins the user has remaining after their purchase.
					player.decreaseCoins(finalCost);
					System.out.println("\nTotal Cost:\t" + totalCost + " gold\nDiscount:\t" + discount + " gold\nFinal Cost:\t" + finalCost + " gold\nGold Coins Remaining:\t" + player.getCoins() + " gold\n");
					System.out.println("Thank you! Your transaction is complete!");
				
					
					if(itemNumber == 1)
					{
						Weapon w = new Weapon("Long Sword", 3, 7);
						player.setWeapon(w);
						System.out.println("You purchased: " + w.getName());
						System.out.println("Your weapon damage is now: " + w.getMinDamage() + " - " + w.getMaxDamage());
					}
					
					else if(itemNumber == 2)
					{
						Weapon w = new Weapon("Short Sword", 1, 4);
						player.setWeapon(w);
						System.out.println("You purchased: " + w.getName());
						System.out.println("Your weapon damage is now: " + w.getMinDamage() + " - " + w.getMaxDamage());
					}
					
					else if(itemNumber == 3)
					{
						Weapon w = new Weapon("Mace", 2, 6);
						player.setWeapon(w);
						System.out.println("You purchased: " + w.getName());
						System.out.println("Your weapon damage is now: " + w.getMinDamage() + " - " + w.getMaxDamage());
					}
					
					else if(itemNumber == 4)
					{
						
						System.out.println("Your strength is now: " + player.getStrength() + " + " + (5 * itemQuantity) + " = " + (player.getStrength() + (5*itemQuantity)));
						player.increaseStrength(5 * itemQuantity);
					}
					
					else 
					{
						System.out.println("Your HP is now: " + player.getHitPoints() + " + " + (10 * itemQuantity) + " = " + (player.getHitPoints() + (10 * itemQuantity)));
						player.increaseHitPoints(10 * itemQuantity);
					}
					
					System.out.print("\nWould you like to make another purchase?\nEnter 1 for \"yes\" or 0 for \"no\":");
					continuePurchase = keyboard.nextInt();
				}
			}while(continuePurchase == 1);	
		}
	}
}