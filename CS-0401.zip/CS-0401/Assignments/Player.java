/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment - Adventure Game (Second Revision)
*/

import java.util.Scanner;
import java.util.Random;

public class Player extends Character
{
	int coins;
	
	
	public Player(String name, int hitPoints, int strength, Weapon weapon)
	{
		super(name, hitPoints, strength, weapon);
		coins = 0;
	}
	
	public void increaseStrength(int strengthIncrease)
	{
		strength += strengthIncrease;
	}
	
	public void setWeapon(Weapon weapon)
	{
		this.weapon = weapon;
	}
	
	public int getCoins()
	{
		return coins;
	}
	
	public void increaseCoins(int coinIncrease)
	{
		coins += coinIncrease;
	}
	
	public void decreaseCoins(int coinDecrease)
	{
		coins -= coinDecrease;
	}
	
	public void attack(Enemy enemy)
	{
		int playerAttack = getStrength() + weapon.getDamage();
		enemy.decreaseHitPoints(playerAttack);
	}
	
	public void battleMinion(Enemy enemy)
	{
		int enemies;
		
		if(enemy.getName().equals("Goblin"))
			enemies = enemy.getNumGoblins();
		else
			enemies = enemy.getNumSkeletons();
		
		for(int i = 0; i < enemies; i++)
		{
			
			Scanner keyboard = new Scanner(System.in);

			System.out.println("***" + getName() + " vs. " + enemy.getName() + " " + (i+1) + "***");
			
			
			while(getHitPoints() > 0 && enemy.getHitPoints() > 0)
			{
				int characterStrength = getStrength(); int characterWeapon = weapon.getDamage();
				int characterATK = characterStrength + characterWeapon;
				int minionStrength = enemy.getStrength(); int minionWeapon = weapon.getDamage();
				int minionATK = minionStrength + minionWeapon;
				
				//Decrease the Goblin's HP accordingly, provided the user still has HP remaining.
				if(getHitPoints() > 0)
				{
					System.out.println(getName() + " attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
					System.out.println(enemy.getName() + " " + (i+1) + " HP is now " + enemy.getHitPoints() + " - " + characterATK + " = " + (enemy.getHitPoints() - characterATK));
					attack(enemy);
				}
				//Decrease the user's HP only if the Goblin is still alive.
				if(getHitPoints() > 0 && enemy.getHitPoints() > 0)
				{
					System.out.println("\n" + enemy.getName() + " " + (i+1) +  " attacks with ATK = " + minionStrength + " + " + minionWeapon + " = " + minionATK);
					System.out.println(getName() + " HP is now " + getHitPoints() + " - " + minionATK + " = " + (getHitPoints() - minionATK) + "\n");
					decreaseHitPoints(minionATK);
				}
				//Reset the Goblin HP for each new Goblin.
				if(enemy.getHitPoints() <= 0)
				{
					System.out.println(getName() + " defeated " + enemy.getName() + " " + (i+1) + "!\n");
					enemy.increaseHitPoints(25);
					increaseCoins(enemy.dropCoins());
					System.out.println("You have gained " + enemy.dropCoins() + " gold coins!");
					System.out.println("Press enter to continue...");
					keyboard.nextLine();
					break;
					
				}
				//Terminate the program if the user has no HP remaining.
				if(isDefeated())
				{
					System.out.println(getName() + " is defeated by " + enemy.getName() + " " + (i+1) + "!\n\nGAME OVER");
					System.exit(0);
				}
			}
		}
	}
	
	public void battleWizard(Enemy enemy)
	{
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("You have reached The Castle! Time to battle The Evil Wizard!");
		System.out.println("***" + getName() + " vs. The Evil Wizard***");
		
		while(getHitPoints() > 0 && enemy.getHitPoints() > 0)
		{
			System.out.println("Choose your action:\n1. Attack\n2. Attempt Spell Cast");
			int action = keyboard.nextInt();
			
			if(action == 1)
			{
				int characterStrength = getStrength(); int characterWeapon = weapon.getDamage();
				int characterATK = characterStrength + characterWeapon;
				int wizardStrength = enemy.getStrength(); int wizardWeapon = weapon.getDamage();
				int wizardATK = wizardStrength + wizardWeapon;
				
				
				System.out.println("***" + getName() + " vs. The Evil Wizard***");
	
				if(getHitPoints() > 0)
				{
					System.out.println(getName() + " attacks with ATK = " + characterStrength + " + " + characterWeapon + " = " + characterATK);
					System.out.println("Evil Wizard HP is now " + enemy.getHitPoints() + " - " + characterATK + " = " + (enemy.getHitPoints() - characterATK));
					attack(enemy);
				}
				if(getHitPoints() > 0 && enemy.getHitPoints() > 0)
				{
					System.out.println("\nEvil Wizard attacks with ATK = " + wizardStrength + " + " + wizardWeapon + " = " + wizardATK);
					System.out.println(getName() + " HP is now " + getHitPoints() + " - " + wizardATK + " = " + (getHitPoints() - wizardATK) + "\n");
					decreaseHitPoints(wizardATK);
				}

			
			}
			else
			{
				int wizardStrength = enemy.getStrength(); int wizardWeapon = weapon.getDamage();
				int wizardATK = wizardStrength + wizardWeapon;
				
				System.out.print("Enter your guess:");
				int guess = keyboard.nextInt();
				
				Random r = new Random();
				int spellCast = r.nextInt(5) + 1;
				
				//If the user guesses correctly, the Evil Wizard's HP evaporates, and the game terminates.
				if(guess == spellCast)
				{
					System.out.println("Correct!\n\n" + getName() + "'s spell is cast successfully! The Wizard's HP is now 0! You win! Congrats!");
					System.exit(0);
				}
				
				//If the user does not guess correctly, then they lose a turn, resulting in a lowered HP.
				else
				{
					System.out.println("\nSorry, your guess is not correct. You just wasted a turn.\n");
					System.out.println("\nEvil Wizard attacks with ATK = " + wizardStrength + " + " + wizardWeapon + " = " + wizardATK);
					System.out.println(getName() + " HP is now " + getHitPoints() + " - " + wizardATK + " = " + (getHitPoints() - wizardATK) + "\n");
					decreaseHitPoints(wizardATK);
					if(isDefeated())
					{
						System.out.println(getName() + " is defeated by Evil Wizard!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
		}
		if(isDefeated())
		{
			System.out.println(getName() + " is defeated by Evil Wizard!\n\nGAME OVER");
			System.exit(0);
		}
		else
		{
			System.out.println(getName() + " defeated Evil Wizard!\n\nYou win! Congrats!");
			System.exit(0);
		}

	}
}