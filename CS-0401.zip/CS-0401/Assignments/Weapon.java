/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment - Adventure Game (Second Revision)
*/

import java.util.Random;

public class Weapon
{
	//Static constants.
	public static final int skeletonMin = 1;
	public static final int skeletonMax = 4;
	public static final int goblinMin = 2;
	public static final int goblinMax = 6;
	public static final int rogueMin = 1;
	public static final int rogueMax = 4;
	public static final int paladinMin = 3;
	public static final int paladinMax = 7;
	public static final int jackieChanMin = 2;
	public static final int jackieChanMax = 6;
	public static final int wizardMin = 4;
	public static final int wizardMax = 10;
	
	String name = "";
	int minDamage, maxDamage;
	
	//Constructor sets variables accordingly.
	public Weapon(String name, int minDamage, int maxDamage)
	{
		this.name = name;
		this.minDamage = minDamage;
		this.maxDamage = maxDamage;
	}
	
	//Returns weapon name.
	public String getName()
	{
		return name;
	}
	
	//Returns min damage.
	public int getMinDamage()
	{
		return minDamage;
	}
	
	//Returns max damage.
	public int getMaxDamage()
	{
		return maxDamage;
	}
	
	//Returns random number of damage between min and max.
	public int getDamage()
	{
		Random r = new Random();
		return r.nextInt(maxDamage - minDamage + 1) + minDamage;
	}
	
}