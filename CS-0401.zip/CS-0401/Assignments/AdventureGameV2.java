/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment 3 - Adventure Game (Revised)
*/

import java.util.Scanner;
import java.util.Random;

public class AdventureGameV2
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		int characterHP = 0;
		int characterStrength = 0;
		int characterMinWeapon = 0;
		int characterMaxWeapon = 0;
		int enemyHP = 0;
		int enemyStrength = 0;
		int enemyMinWeapon = 0;
		int enemyMaxWeapon = 0;
		int enemies = 0;
		int goldCoins = 0;
		String characterName = "";
		String enemyName = "";
		int[] characterArray = new int[5];
		int[] enemyArray = new int[4];
		
		
		//Welcome the user to the game, and then get their character.
		System.out.println("Welcome to the Adventure Game. Here marks the beginning of your journey!");
		int character = getCharacter();
		
		//Provide each character with their corresponding HP and strength attributes.
		if(character == 1)
		{
			System.out.println("You chose: Rogue\n");
			characterName = "Rogue";
			characterHP = 50;
			characterStrength = 7;
		}
		else if(character == 2)
		{
			System.out.println("You chose: Paladin\n");
			characterName = "Paladin";
			characterHP = 30;
			characterStrength = 12;
		}
		else
		{
			System.out.println("You chose: Jackie Chan\n");
			characterName = "Jackie Chan";
			characterHP = 40;
			characterStrength = 10;
		}
		
		//Get the user's path.
		int path = getPath();
		
		if(character == 1)
		{
			if(path == 1)
			{
				enemies = 2 + r.nextInt(4);
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter " + enemies + "Goblins! Time for battle!");
				enemyName = "Goblin";
				enemyHP = 25;
				enemyStrength = 4;
				characterMinWeapon = 1;
				characterMaxWeapon = 4;
				enemyMinWeapon = 2;
				enemyMaxWeapon = 6;
				goldCoins = 0;
				
				characterArray[0] = characterHP;
				characterArray[1] = characterStrength;
				characterArray[2] = characterMinWeapon;
				characterArray[3] = characterMaxWeapon;
				characterArray[4] = goldCoins;

				enemyArray[0] = enemyHP;
				enemyArray[1] = enemyStrength;
				enemyArray[2] = enemyMinWeapon;
				enemyArray[3] = enemyMaxWeapon;
				
				characterArray = fightMinion(characterArray, enemyArray, enemies, characterName, enemyName);
				visitItemShop(characterArray);
				
			}
			else
			{
				enemies = 3 + r.nextInt(5);
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter " + enemies + "Skeletons! Time for battle!");
				goldCoins = 0;
				enemyName = "Skeleton";
				enemyHP = 25;
				enemyStrength = 3;
				characterMinWeapon = 1;
				characterMaxWeapon = 4;
				enemyMinWeapon = 1;
				enemyMaxWeapon = 4;
				
				characterArray[0] = characterHP;
				characterArray[1] = characterStrength;
				characterArray[2] = characterMinWeapon;
				characterArray[3] = characterMaxWeapon;
				characterArray[4] = goldCoins;

				enemyArray[0] = enemyHP;
				enemyArray[1] = enemyStrength;
				enemyArray[2] = enemyMinWeapon;
				enemyArray[3] = enemyMaxWeapon;
				
				characterArray = fightMinion(characterArray, enemyArray, enemies, characterName, enemyName);
				visitItemShop(characterArray);		
			}
			
			System.out.println("Your HP is: " + characterArray[0]);
			
			int spellCast = r.nextInt(5) + 1;
			enemyHP = 40;
			enemyStrength = 8;
			enemyMinWeapon = 4;
			enemyMaxWeapon = 10;

			enemyArray[0] = enemyHP;
			enemyArray[1] = enemyStrength;
			enemyArray[2] = enemyMinWeapon;
			enemyArray[3] = enemyMaxWeapon;
			
			fightWizard(characterArray, enemyArray, characterName, spellCast);
		}
		
		else if(character == 2)
		{
			if(path == 1)
			{
				enemies = 2 + r.nextInt(4);
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter " + enemies + "Goblins! Time for battle!");
				enemyName = "Goblin";
				enemyHP = 25;
				enemyStrength = 4;
				characterMinWeapon = 3;
				characterMaxWeapon = 7;
				enemyMinWeapon = 2;
				enemyMaxWeapon = 6;
				goldCoins = 0;
				
				characterArray[0] = characterHP;
				characterArray[1] = characterStrength;
				characterArray[2] = characterMinWeapon;
				characterArray[3] = characterMaxWeapon;
				characterArray[4] = goldCoins;

				enemyArray[0] = enemyHP;
				enemyArray[1] = enemyStrength;
				enemyArray[2] = enemyMinWeapon;
				enemyArray[3] = enemyMaxWeapon;
				
				characterArray = fightMinion(characterArray, enemyArray, enemies, characterName, enemyName);
				visitItemShop(characterArray);
				
			}
			else
			{
				enemies = 3 + r.nextInt(5);
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter " + enemies + "Skeletons! Time for battle!");
				goldCoins = 0;
				enemyName = "Skeleton";
				enemyHP = 25;
				enemyStrength = 3;
				characterMinWeapon = 3;
				characterMaxWeapon = 7;
				enemyMinWeapon = 1;
				enemyMaxWeapon = 4;
				
				characterArray[0] = characterHP;
				characterArray[1] = characterStrength;
				characterArray[2] = characterMinWeapon;
				characterArray[3] = characterMaxWeapon;
				characterArray[4] = goldCoins;

				enemyArray[0] = enemyHP;
				enemyArray[1] = enemyStrength;
				enemyArray[2] = enemyMinWeapon;
				enemyArray[3] = enemyMaxWeapon;
				
				characterArray = fightMinion(characterArray, enemyArray, enemies, characterName, enemyName);
				visitItemShop(characterArray);		
			}
			
			System.out.println("Your HP is: " + characterArray[0]);
			
			int spellCast = r.nextInt(5) + 1;
			enemyHP = 40;
			enemyStrength = 8;
			enemyMinWeapon = 4;
			enemyMaxWeapon = 10;
			
			enemyArray[0] = enemyHP;
			enemyArray[1] = enemyStrength;
			enemyArray[2] = enemyMinWeapon;
			enemyArray[3] = enemyMaxWeapon;
			
			fightWizard(characterArray, enemyArray, characterName, spellCast);
		}
		
		else
		{
			if(path == 1)
			{
				enemies = 2 + r.nextInt(4);
				System.out.println("You chose: The Forest\nOnce you enter The Forest, you encounter " + enemies + "Goblins! Time for battle!");
				enemyName = "Goblin";
				enemyHP = 25;
				enemyStrength = 4;
				characterMinWeapon = 2;
				characterMaxWeapon = 6;
				enemyMinWeapon = 2;
				enemyMaxWeapon = 6;
				goldCoins = 0;
				
				characterArray[0] = characterHP;
				characterArray[1] = characterStrength;
				characterArray[2] = characterMinWeapon;
				characterArray[3] = characterMaxWeapon;
				characterArray[4] = goldCoins;

				enemyArray[0] = enemyHP;
				enemyArray[1] = enemyStrength;
				enemyArray[2] = enemyMinWeapon;
				enemyArray[3] = enemyMaxWeapon;
				
				characterArray = fightMinion(characterArray, enemyArray, enemies, characterName, enemyName);
				visitItemShop(characterArray);
				
			}
			else
			{
				enemies = 3 + r.nextInt(5);
				System.out.println("You chose: The Graveyard\nOnce you enter The Graveyard, you encounter " + enemies + "Skeletons! Time for battle!");
				goldCoins = 0;
				enemyName = "Skeleton";
				enemyHP = 25;
				enemyStrength = 3;
				characterMinWeapon = 2;
				characterMaxWeapon = 6;
				enemyMinWeapon = 1;
				enemyMaxWeapon = 4;
				
				characterArray[0] = characterHP;
				characterArray[1] = characterStrength;
				characterArray[2] = characterMinWeapon;
				characterArray[3] = characterMaxWeapon;
				characterArray[4] = goldCoins;

				enemyArray[0] = enemyHP;
				enemyArray[1] = enemyStrength;
				enemyArray[2] = enemyMinWeapon;
				enemyArray[3] = enemyMaxWeapon;
				
				characterArray = fightMinion(characterArray, enemyArray, enemies, characterName, enemyName);
				visitItemShop(characterArray);		
			}
			
			System.out.println("Your HP is: " + characterArray[0]);
			
			int spellCast = r.nextInt(5) + 1;
			enemyHP = 40;
			enemyStrength = 8;
			enemyMinWeapon = 4;
			enemyMaxWeapon = 10;
		
			enemyArray[0] = enemyHP;
			enemyArray[1] = enemyStrength;
			enemyArray[2] = enemyMinWeapon;
			enemyArray[3] = enemyMaxWeapon;
			
			fightWizard(characterArray, enemyArray, characterName, spellCast);
		}
	}
	
	public static int getCharacter()
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Here are the characters:\n1. Rogue\n2. Paladin\n3. Jackie Chan\n");
		System.out.print("Which character would you like to choose?:\n");
		return keyboard.nextInt();
	}
	
	public static int getPath()
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("The Evil Wizard must be defeated! He is in The Castle. To get to The Castle, you must travel through either:\n\n1. The Forest\n2. The Graveyard\n");
		System.out.print("Which path would you like to choose?:\n");
		return keyboard.nextInt();
	}
	
	public static int[] fightMinion(int[] ch, int[] en, int enemies, String characterName, String enemyName)
	{
		//Pass through the loop three times, resetting the goblin HP to 25, assuming the user stays alive.
		for(int i = 0; i < enemies; i++)
		{
			Random r = new Random();
			Scanner keyboard = new Scanner(System.in);
			int characterWeapon = ch[2] + r.nextInt(ch[3] - ch[2] + 1);
			int characterATK = ch[1] + characterWeapon;
			int enemyWeapon = en[2] + r.nextInt(en[3] - en[2] + 1);
			int enemyATK = en[1] + enemyWeapon;
			
			System.out.println("***" + characterName + " vs. " + enemyName + " " + (i+1) + "***");
			
			
			while(ch[0] > 0 && en[0] > 0)
			{
				//Decrease the Goblin's HP accordingly, provided the user still has HP remaining.
				if(ch[0] > 0)
				{
					System.out.println(characterName + " attacks with ATK = " + ch[1] + " + " + characterWeapon + " = " + characterATK);
					System.out.println(enemyName + " " + (i+1) + " HP is now " + en[0] + " - " + characterATK + " = " + (en[0] - characterATK));
					en[0] -= characterATK;
				}
				//Decrease the user's HP only if the Goblin is still alive.
				if(ch[0] > 0 && en[0] > 0)
				{
					System.out.println("\n" + enemyName + " " + (i+1) +  " attacks with ATK = " + en[1] + " + " + enemyWeapon + " = " + enemyATK);
					System.out.println(characterName + " HP is now " + ch[0] + " - " + enemyATK + " = " + (ch[0] - enemyATK) + "\n");
					ch[0] -= enemyATK;
				}
				//Reset the Goblin HP for each new Goblin.
				if(en[0] <= 0)
				{
					System.out.println(characterName + " defeated " + enemyName + " " + (i+1) + "!\n");
					en[0] = 25;
					ch[4] += 30 + r.nextInt(21);
					System.out.println("You have gained " + ch[4] + " gold coins!");
					System.out.println("Press enter to continue...");
					keyboard.nextLine();
					break;
					
				}
				//Terminate the program if the user has no HP remaining.
				if(ch[0] <= 0)
				{
					System.out.println(characterName + " is defeated by " + enemyName + " " + (i+1) + "!\n\nGAME OVER");
					System.exit(0);
				}
			}
		}
		
		return ch;
	}
	
	public static void visitItemShop(int[] array)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		int itemNumber, itemQuantity, totalCost, discount, finalCost;
		
		//Instantiate all item prices as constants.
		final int longSwordPrice = 120;
		final int shortSwordPrice = 90;
		final int macePrice = 80;
		final int ringOfStrengthPrice = 150;
		final int healingPotionPrice = 10;
		
		System.out.print("Would you like to visit the Item Shop?\nEnter 1 for \"yes\" or 0 for \"no\":");
		int continuePurchase = keyboard.nextInt();
		
		if(continuePurchase == 1)
		{
			do{
				//Welcome the user to the Item Shop and display all items and their prices.
				System.out.println("Welcome to The Item Shop!");
				System.out.println("You currently have " + array[4] + "gold.");
				System.out.println("\nHere's what we have for sale (all prices are in units of gold):\n1. Long Sword\t" + longSwordPrice + "\n2. Short Sword\t" + shortSwordPrice + "\n3. Mace\t" + macePrice + "\n4. Ring Of Strengh\t" + ringOfStrengthPrice + "\n5. Healing Potion\t" + healingPotionPrice);
				
				//Prompt the user to choose an item, and then store it.
				System.out.println("Please enter the item number:");
				itemNumber = keyboard.nextInt();
				
				//Prompt the user to enter the quantity of the item they chose, and then store it.
				System.out.println("Please enter the quantity:");
				itemQuantity = keyboard.nextInt();
				
				String item;
				int price;
				
				//Specify item name and price to long sword.
				if(itemNumber == 1)
				{
					item = "Long Sword";
					price = longSwordPrice;
					if(itemQuantity > 1)
					{
						System.out.println("You may only purchase one of this item. I will change your quantity request to one!");
						itemQuantity = 1;
					}
				}
				
				//Specify item name and price to short sword.
				else if(itemNumber == 2)
				{
					item = "Short Sword";
					price = shortSwordPrice;
					if(itemQuantity > 1)
					{
						System.out.println("You may only purchase one of this item. I will change your quantity request to one!");
						itemQuantity = 1;
					}
				}
				
				//Specify item name and price to mace.
				else if(itemNumber == 3)
				{
					item = "Mace";
					price = macePrice;
					if(itemQuantity > 1)
					{
						System.out.println("You may only purchase one of this item. I will change your quantity request to one!");
						itemQuantity = 1;
					}
				}
				
				//Specify item name and price to Ring of Strength.
				else if(itemNumber == 4)
				{
					item = "Ring of Strength";
					price = ringOfStrengthPrice;
				}
				
				//Specify item name and price to healing potion.
				else
				{
					item = "Healing Potion";
					price = healingPotionPrice;
				}
					
				//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
				if(itemQuantity >= 3)
				{
					totalCost = price * itemQuantity;
					discount = totalCost / 10;
					finalCost = totalCost - discount;
				}
				//Otherwise, calculate the total and final costs.
				else
				{
					totalCost = price * itemQuantity;
					discount = 0;
					finalCost = totalCost;
				}
				
				//If the user does not have sufficient funds, prompt them to come back later.
				if(finalCost > array[4])
				{
					System.out.println("Your purchase cannot be completed! You don't have enough gold coins!");
					System.out.print("\nWould you like to make another purchase?\nEnter 1 for \"yes\" or 0 for \"no\":");
					continuePurchase = keyboard.nextInt();
				}
				
				//Otherwise, display all of the information to the user.
				else
				{
					//Determine how many gold coins the user has remaining after their purchase.
					array[4] -= finalCost;
					System.out.println("\nTotal Cost:\t" + totalCost + " gold\nDiscount:\t" + discount + " gold\nFinal Cost:\t" + finalCost + " gold\nGold Coins Remaining:\t" + array[4] + " gold\n");
					System.out.println("Thank you! Your transaction is complete!");
					System.out.print("\nWould you like to make another purchase?\nEnter 1 for \"yes\" or 0 for \"no\":");
					continuePurchase = keyboard.nextInt();
				
					System.out.println("You purchased: " + item);
					
					if(itemNumber == 1)
					{
						array[2] = 3;
						array[3] = 7;
						System.out.println("Your weapon damage is now: 3-7");
					}
					
					else if(itemNumber == 2)
					{
						array[2] = 1;
						array[3] = 4;
						System.out.println("Your weapon damage is now: 1-4");
					}
					
					else if(itemNumber == 3)
					{
						array[2] = 2;
						array[3] = 6;
						System.out.println("Your weapon damage is now: 2-6");
					}
					
					else if(itemNumber == 4)
					{
						System.out.println("Your strength is now: " + array[1] + "+ " + (5*itemQuantity) + " = " + (array[1] + (5*itemQuantity)));
						array[1] += 5 * itemQuantity;
					}
					
					else 
					{
						System.out.println("Your HP is now: " + array[0] + "+ " + (10*itemQuantity) + " = " + (array[0] + (10*itemQuantity)));
						array[0] += 10 * itemQuantity;
					}
				}
			}while(continuePurchase == 1);	
		}
	}
	
	public static void fightWizard(int[] ch, int[] en, String characterName, int spellCast)
	{
		Scanner keyboard = new Scanner(System.in);
		Random r = new Random();
		
		System.out.println("You have reached The Castle! Time to battle The Evil Wizard!");
		System.out.println("***" + characterName + " vs. The Evil Wizard***");
		
		while(ch[0] > 0 && en[0] > 0)
		{
			System.out.println("Choose your action:\n1. Attack\n2. Attempt Spell Cast");
			int action = keyboard.nextInt();
			
			if(action == 1)
			{
				int characterWeapon = ch[2] + r.nextInt(ch[3] - ch[2] + 1);
				int characterATK = ch[1] + characterWeapon;
				int enemyWeapon = en[2] + r.nextInt(en[3] - en[2] + 1);
				int enemyATK = en[1] + enemyWeapon;
				
				System.out.println("***" + characterName + " vs. The Evil Wizard***");
	
				if(ch[0] > 0)
				{
					System.out.println(characterName + " attacks with ATK = " + ch[1] + " + " + characterWeapon + " = " + characterATK);
					System.out.println("Evil Wizard HP is now " + en[0] + " - " + characterATK + " = " + (en[0] - characterATK));
					en[0] -= characterATK;
				}
				if(ch[0] > 0 && en[0] > 0)
				{
					System.out.println("\nEvil Wizard attacks with ATK = " + en[1] + " + " + enemyWeapon + " = " + enemyATK);
					System.out.println(characterName + " HP is now " + ch[0] + " - " + enemyATK + " = " + (ch[0] - enemyATK) + "\n");
					ch[0] -= enemyATK;
				}
				if(en[0] <= 0)
				{
					System.out.println(characterName + " is defeated Evil Wizard!\n\nYou win! Congrats!");
					System.exit(0);
				}
				if(ch[0] <= 0)
				{
					System.out.println(characterName + " is defeated by Evil Wizard!\n\nGAME OVER");
					System.exit(0);
				}
			
			}
			else
			{
				int characterWeapon = ch[2] + r.nextInt(ch[3] - ch[2] + 1);
				int characterATK = ch[1] + characterWeapon;
				int enemyWeapon = en[2] + r.nextInt(en[3] - en[2] + 1);
				int enemyATK = en[1] + enemyWeapon;
				
				System.out.print("Enter your guess:");
				int guess = keyboard.nextInt();
				
				//If the user guesses correctly, the Evil Wizard's HP evaporates, and the game terminates.
				if(guess == spellCast)
				{
					System.out.println("Correct!\n\n" + characterName + "'s spell is cast successfully! The Wizard's HP is now 0! You win! Congrats!");
					en[0] = 0;
				}
				
				//If the user does not guess correctly, then they lose a turn, resulting in a lowered HP.
				else
				{
					System.out.println("\nSorry, your guess is not correct. You just wasted a turn.\n");
					System.out.println("\nEvil Wizard attacks with ATK = " + en[1] + " + " + enemyWeapon + " = " + enemyATK);
					System.out.println(characterName + " HP is now " + ch[0] + " - " + enemyATK + " = " + (ch[0] - enemyATK) + "\n");
					ch[0] -= enemyATK;
					if(ch[0] <= 0)
					{
						System.out.println(characterName + " is defeated by Evil Wizard!\n\nGAME OVER");
						System.exit(0);
					}
				}
			}
		}
	}
	
}