/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment 1 - Item Shop
*/
import java.util.Scanner;

public class ItemShopAssignment
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String name;
		int goldCoins;
		int itemNumber;
		int itemQuantity;
		int totalCost;
		int discount;
		int finalCost;
		
		//Instantiate all item prices as constants.
		final int longSwordPrice = 120;
		final int shortSwordPrice = 90;
		final int macePrice = 80;
		final int magicRingPrice = 150;
		final int healingPotionPrice = 10;
		
		//Prompt the user to enter their name, and then store it.
		System.out.println("Please enter your name:");
		name = keyboard.next();
		
		//Prompt the user to enter their amount of coins, and then store it.
		System.out.println("Please enter your amount of gold coins:");
		goldCoins = keyboard.nextInt();
		
		//Welcome the user to the Item Shop and display all items and their prices.
		System.out.println("Welcome to The Item Shop, " + name + "!\n\nHere's what we have for sale (all prices are in units of gold):");
		System.out.println("1. Long Sword\t" + longSwordPrice + "\n2. Short Sword\t" + shortSwordPrice + "\n3. Mace\t" + macePrice + "\n4. Magic Ring\t" + magicRingPrice + "\n5. Healing Potion\t" + healingPotionPrice);
		
		//Prompt the user to choose an item, and then store it.
		System.out.println("Please enter the item number:");
		itemNumber = keyboard.nextInt();
		
		//Prompt the user to enter the quantity of the item they chose, and then store it.
		System.out.println("Please enter the quantity:");
		itemQuantity = keyboard.nextInt();
		
		//Calculate costs for the long sword.
		if(itemNumber == 1)
		{
			//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
			if(itemQuantity >= 3)
			{
				totalCost = longSwordPrice * itemQuantity;
				discount = totalCost / 10;
				finalCost = totalCost - discount;
			}
			//Otherwise, calculate the total and final costs.
			else
			{
				totalCost = longSwordPrice * itemQuantity;
				discount = 0;
				finalCost = totalCost;
			}
		}
		
		//Calculate costs for the short sword.
		else if(itemNumber == 2)
		{
			//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
			if(itemQuantity >= 3)
			{
				totalCost = shortSwordPrice * itemQuantity;
				discount = totalCost / 10;
				finalCost = totalCost - discount;
			}
			//Otherwise, calculate the total and final costs.
			else
			{
				totalCost = shortSwordPrice * itemQuantity;
				discount = 0;
				finalCost = totalCost;
			}
		}
		
		//Calculate costs for the mace.
		else if(itemNumber == 3)
		{
			//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
			if(itemQuantity >= 3)
			{
				totalCost = macePrice * itemQuantity;
				discount = totalCost / 10;
				finalCost = totalCost - discount;
			}
			//Otherwise, calculate the total and final costs.
			else
			{
				totalCost = macePrice * itemQuantity;
				discount = 0;
				finalCost = totalCost;
			}
		}
		
		//Calculate costs for the magic ring.
		else if(itemNumber == 4)
		{
			//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
			if(itemQuantity >= 3)
			{
				totalCost = magicRingPrice * itemQuantity;
				discount = totalCost / 10;
				finalCost = totalCost - discount;
			}
			//Otherwise, calculate the total and final costs.
			else
			{
				totalCost = magicRingPrice * itemQuantity;
				discount = 0;
				finalCost = totalCost;
			}
		}
		
		//Calculate costs for the healing potion.
		else
		{
			//Calculate the total cost, discount, and final cost for a quantity 3 or higher.
			if(itemQuantity >= 3)
			{
				totalCost = healingPotionPrice * itemQuantity;
				discount = totalCost / 10;
				finalCost = totalCost - discount;
			}
			//Otherwise, calculate the total and final costs.
			else
			{
				totalCost = healingPotionPrice * itemQuantity;
				discount = 0;
				finalCost = totalCost;
			}
		}
		
		//If the user does not have sufficient funds, prompt them to come back later.
		if(finalCost > goldCoins)
			System.out.println("Your purchase cannot be completed! Please come back when you have enough gold coins! Thank you!");
		
		//Otherwise, display all of the information to the user.
		else
		{
			//Determine how many gold coins the user has remaining after their purchase.
			goldCoins -= finalCost;
			System.out.println("\nTotal Cost:\t" + totalCost + " gold\nDiscount:\t" + discount + " gold\nFinal Cost:\t" + finalCost + " gold\nGold Coins Remaining:\t" + goldCoins + " gold\n");
			System.out.println("Thank you, " + name + "! Your transaction is complete! Please come again!");
		}
	}
}