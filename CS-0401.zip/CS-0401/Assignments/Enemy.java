/*
Collin Dreher
CS-401
Fall Semester 2015
Assignment - Adventure Game (Second Revision)
*/

import java.util.Random;

public class Enemy extends Character
{
	static Random r = new Random();
	
	//Constructor that sets variables accordingly.
	public Enemy(String name, int hitPoints, int strength, Weapon weapon)
	{
		//Calls the superclass constructor.
		super(name, hitPoints, strength, weapon);
	}
	
	//Returns a random number of coins.
	public int dropCoins()
	{
		return 30 + r.nextInt(21);
	}
	
	//Returns a random number of goblins.
	public static int getNumGoblins()
	{
		return r.nextInt(4) + 2;
	}
	
	//Returns a random number of skeletons.
	public static int getNumSkeletons()
	{
		return r.nextInt(5) + 3;
	}
}