public class EmployeeDriver
{
	public static void main(String[] args)
	{
		// create an Employee object
		Employee employee1 = new Employee("Jeff", 5, 60, 32.40);
		
		// print out name of employee1
		System.out.println("employee1 name: " + employee1.getName());
		
		// print out the gross pay of employee1
		System.out.println("Gross pay of employee1 is: $" + employee1.getGrossPay());
		
		// create a copy of employee1; call it employee1_copy
		Employee employee1_copy = new Employee(employee1);
		
		// check if the two objects are equal
		if (employee1.equals(employee1_copy))
			System.out.println("The two objects are equal.");
		else
			System.out.println("The two objects are NOT equal");
		
		// print out employee1_copy's current state
		System.out.println(employee1_copy.toString());
	}
}