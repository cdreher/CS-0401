
public class Employee
{
	private String name;
	private int idNumber;
	private double hoursWorked, payRate;
	
	public Employee(String name, int idNumber, double hoursWorked, double payRate)
	{
		this.name = name;
		this.idNumber = idNumber;
		this.hoursWorked = hoursWorked;
		this.payRate = payRate;
	}
	
	public Employee(Employee e)
	{
		name = e.getName();
		idNumber = e.getidNumber();
		hoursWorked = e.gethoursWorked();
		payRate = e.getpayRate();
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getidNumber()
	{
		return idNumber;
	}
	
	public double gethoursWorked()
	{
		return hoursWorked;
	}
	
	public double getpayRate()
	{
		return payRate;
	}
	
	public double getGrossPay()
	{
		return payRate * hoursWorked;
	}
	
	public boolean equals(Employee e)
	{
		if(e.getidNumber() == idNumber)
			return true;
		return false;
	}
	
	public String toString()
	{
		return "Name: " + name + "\nID Number: " + idNumber + "\nHours Worked: " + hoursWorked + "\nPay Rate: " + payRate + "\nGross pay: " + this.getGrossPay();
	}
	
}