public class FinalExam3RelatableDriver
{
	//I was in class today....polymorphism!
}