import java.util.Scanner;

public class VolumeCalculator
{
	public static void main(String[] args)
	{
		int d1 = getInput();
		int d2 = getInput();
		int d3 = getInput();
		int volume = calculate(d1, d2, d3);
		displayResult(d1, d2, d3, volume);
	}
	
	public static int getInput()
	{
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter a dimension value:");
		int dimension = keyboard.nextInt();
		
		return dimension;
	}
	
	public static int calculate(int d1, int d2, int d3)
	{
		return d1 * d2 * d3;
	}
	
	public static void displayResult(int d1, int d2, int d3, int volume)
	{
		System.out.println("The volume of the solid is:\n" + d1 + " units x " + d2 + " units x " + d3 + " units = " + volume + " units^3");
	}
}