import java.util.Scanner;

public class GroupActivity1
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int first;
		int second;
		int product;
		
		System.out.println("Please enter your first number!");
		first = keyboard.nextInt();
		
		System.out.println("Please enter your second number!");
		second = keyboard.nextInt();
		
		product = first * second;
		
		System.out.println("Here is the product of your two numbers!\n" + product);
		
		if(product < 0)
			System.out.println("The product is negative.");
		else
			System.out.println("The product is positive.");
	}
}