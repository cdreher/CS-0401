public class CheckingAccount
{
	private double balance;
	
	public CheckingAccount(double amount)
	{
		balance = amount;
	}
	
	public double getBalance()
	{
		return balance;
	}
	
	public void withdraw(double amount)
	{
		if(balance >= amount)
			balance -= amount;
		else
			System.out.println("Cannot complete withdrawal: insufficient funds.");
	}
	
	public void deposit(double amount)
	{
		balance += amount;
	}
}