public class ExamScores 
{
	public static void main(String[] args)
	{
		double[] array = new double[5];
		double total = 0.0;
		array[0] = 98.0;
		array[1] = 91.0;
		array[2] = 84.5;
		array[3] = 62.5;
		array[4] = 25.0;
		
		System.out.println("The exam scores are:");
		
		for(int i = 0; i < array.length; i++)
		{
			System.out.printf("%.2f\n", array[i]);
			total += array[i];
		}
		
		double average = total / 5;
		
		System.out.println();
		System.out.printf("The average of the scores is: %.2f\n", average);
	}
}