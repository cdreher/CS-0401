import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;

public class CustomerSim
{	
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int customers;
		int continueSim;
		
		do{
			customers = getNumCustomers();
			printTableHeading();
			
			for(int i = 0; i < customers; i++)
				simulateCustomer(i + 1);
		
			System.out.print("Please enter \"1\" to simulate again or \"0\" to exit:");
			continueSim = keyboard.nextInt();
		}while(continueSim == 1);
	}
	
	public static int getNumCustomers()
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.print("How many customers would you like to simulate?");
		return keyboard.nextInt();
	}
	
	public static void printTableHeading()
	{
		System.out.println("Customer\tSelection\tQuantity\tTotal Cost");
		System.out.println("--------\t---------\t--------\t----------");
	}
	
	public static void simulateCustomer(int customerNumber)
	{
		Random r = new Random();
		int randomSelection = r.nextInt(4) + 1;
		int randomQuantity = r.nextInt(4) + 1;
		String itemName;
		double totalCost;
			
		if(randomSelection == 1)
		{
			totalCost = randomQuantity * 1.50;
			itemName = "Coffee";
		}	
		else if(randomSelection == 2)
		{
			totalCost = randomQuantity * 3.50;
			itemName = "Latte";
		}	
		else if(randomSelection == 3)
		{
			totalCost = randomQuantity * 3.25;
			itemName = "Cappuccino";
		}	
		else 
		{
			totalCost = randomQuantity * 2.00;
			itemName = "Espresso";
		}	
		
		printCustomerResults(customerNumber, itemName, randomQuantity, totalCost);
	}
	
	public static void printCustomerResults(int customerNumber, String itemName, int randomQuantity, double totalCost)
	{
		DecimalFormat df = new DecimalFormat(".00");
		if((itemName.equals("Coffee")) || (itemName.equals("Latte")))
			System.out.println(customerNumber + "\t\t" + itemName + "\t\t" + randomQuantity + "\t\t" + df.format((totalCost)));
		else
			System.out.println(customerNumber + "\t\t" + itemName + "\t" + randomQuantity + "\t\t" + df.format((totalCost)));
	}
}