public class GroupActivity2
{
	public static void main(String[] args)
	{
		int[] myArray = { 0, 1, 2, 3, 4, 5 };
		int arrayIndex;
		
		//Test 1
		arrayIndex = findInteger(myArray, 2);
		
		if (arrayIndex != -1)
			System.out.println("The value 2 was found in myArray at index: " + arrayIndex);
		else
			System.out.println("The value 2 was not found in myArray.");
		
		//Test 2
		arrayIndex = findInteger(myArray, 6);
		
		if (arrayIndex != -1)
			System.out.println("The value 6 was found in myArray at index: " + arrayIndex);
		else
			System.out.println("The value 6 was not found in myArray.");
	}

	public static int findInteger(int[] array, int element)
	{
		/*index will store the current index; found will be set to
		"true" if the element is found in the array*/
		int index = 0;
		boolean found = false;

		while(!found && (index < array.length))
		{
			//TODO: write an if-else statement that will set found to "true" if
			//the current array element is equal to element; otherwise, increment
			//index by 1
			if(array[index] == element)
				found = true;
			else
				index++;

		}
		
		//TODO: if element was not found in the array, set index to -1
		if(found == false)
			index = -1;
		
		
		//TODO: return index
		return index;
	}
}