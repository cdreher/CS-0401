public class GroupActivityArrays1
{
	public static void main(String[] args)
	{
		int[] myArray = createArray(100);
		int arraySum = computeSum(myArray);
		
		System.out.println("The sum of the elements is: " + arraySum);
	}
	
	public static int[] createArray(int n)
	{
		int[] array = new int[n];
		int val = 1;
		
		for(int i = 0; i < n; i++)
			array[i] = val++;
		
		return array;
		
	}
	
	public static int computeSum(int[] a)
	{
		int sum = 0;
		
		
		for(int i = 0; i < a.length; i++)
			sum += a[i];
		
		return sum;
		
	}

}